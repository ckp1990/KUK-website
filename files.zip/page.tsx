"use client";

import { useState, useMemo } from "react";
import Image from "next/image";
import { ExternalLink, Search, X } from "lucide-react";
import {
  tabs,
  books,
  scientificArticles,
  popularArticles,
} from "@/lib/data/publications";

// Derive unique decades from the articles for the filter
const allDecades = Array.from(
  new Set(
    scientificArticles
      .map((a) => (a.year ? `${Math.floor(Number(a.year) / 10) * 10}s` : null))
      .filter(Boolean)
  )
).sort((a, b) => b!.localeCompare(a!)) as string[];

const Publications = () => {
  const [activeTab, setActiveTab] = useState("scientific");
  const [bookCategory, setBookCategory] = useState("popular");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDecade, setSelectedDecade] = useState<string>("All");

  const filteredBooks = useMemo(
    () => books.filter((book) => book.category === bookCategory),
    [bookCategory]
  );

  const filteredArticles = useMemo(() => {
    return scientificArticles.filter((article) => {
      const matchesSearch =
        searchQuery.trim() === "" ||
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.authors.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.journal.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDecade =
        selectedDecade === "All" ||
        (article.year &&
          `${Math.floor(Number(article.year) / 10) * 10}s` === selectedDecade);

      return matchesSearch && matchesDecade;
    });
  }, [searchQuery, selectedDecade]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-primary border-b pb-4">
        Publications
      </h1>

      {/* Tabs */}
      <div className="flex space-x-4 mb-8 border-b border-gray-200 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`py-3 px-6 font-medium text-lg transition-colors border-b-2 whitespace-nowrap ${
              activeTab === tab.id
                ? "border-primary text-primary"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {tab.label}
            {tab.id === "scientific" && (
              <span className="ml-2 text-sm bg-primary text-white rounded-full px-2 py-0.5">
                {scientificArticles.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="min-h-[400px]">
        {/* ── Books ── */}
        {activeTab === "books" && (
          <div>
            <div className="mb-6 flex justify-end">
              <select
                value={bookCategory}
                onChange={(e) => setBookCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary bg-white text-gray-700"
              >
                <option value="popular">Popular Books</option>
                <option value="scientific">Scientific Books</option>
              </select>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {filteredBooks.map((book, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center text-center group cursor-pointer"
                >
                  <div className="relative h-64 w-44 mb-4 shadow-lg transition-transform duration-300 group-hover:scale-105">
                    <Image
                      src={book.image}
                      alt={book.title}
                      fill
                      className="object-cover rounded-md"
                    />
                    <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                      {book.language}
                    </div>
                  </div>
                  <h3 className="font-bold text-lg text-gray-800 group-hover:text-primary transition-colors">
                    {book.title}
                  </h3>
                  <span className="text-gray-500 text-sm">({book.year})</span>
                </div>
              ))}
            </div>
            {filteredBooks.length === 0 && (
              <p className="text-center text-gray-500 py-10">
                No books found in this category.
              </p>
            )}
          </div>
        )}

        {/* ── Scientific Articles ── */}
        {activeTab === "scientific" && (
          <div>
            {/* Search + Decade filter bar */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <div className="relative flex-grow">
                <Search
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  size={18}
                />
                <input
                  type="text"
                  placeholder="Search by title, author or journal…"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-9 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-sm"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X size={16} />
                  </button>
                )}
              </div>

              <div className="flex gap-2 flex-wrap">
                {["All", ...allDecades].map((decade) => (
                  <button
                    key={decade}
                    onClick={() => setSelectedDecade(decade)}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                      selectedDecade === decade
                        ? "bg-primary text-white"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {decade}
                  </button>
                ))}
              </div>
            </div>

            {/* Results count */}
            <p className="text-sm text-gray-500 mb-4">
              Showing{" "}
              <span className="font-semibold text-gray-700">
                {filteredArticles.length}
              </span>{" "}
              of {scientificArticles.length} articles
              {(searchQuery || selectedDecade !== "All") && (
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedDecade("All");
                  }}
                  className="ml-2 text-primary hover:underline"
                >
                  Clear filters
                </button>
              )}
            </p>

            {/* Article list */}
            <div className="space-y-3">
              {filteredArticles.map((article, index) => (
                <div
                  key={index}
                  className="bg-white p-5 rounded-lg shadow-sm border border-gray-100 hover:shadow-md hover:border-primary/20 transition-all"
                >
                  {/* Year badge + title row */}
                  <div className="flex items-start gap-3">
                    <span className="shrink-0 text-xs font-bold bg-primary/10 text-primary px-2 py-1 rounded mt-0.5">
                      {article.year}
                    </span>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 leading-snug mb-1">
                        {article.link ? (
                          <a
                            href={article.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:text-primary transition-colors inline-flex items-start gap-1 group"
                          >
                            <span>{article.title}</span>
                            <ExternalLink
                              size={14}
                              className="shrink-0 mt-1 opacity-0 group-hover:opacity-100 transition-opacity text-primary"
                            />
                          </a>
                        ) : (
                          article.title
                        )}
                      </h3>
                      <p className="text-sm text-gray-600 mb-1">
                        {article.authors}
                      </p>
                      <p className="text-sm text-gray-500 italic">
                        {article.journal}
                      </p>
                    </div>
                  </div>
                </div>
              ))}

              {filteredArticles.length === 0 && (
                <div className="text-center py-16 text-gray-500">
                  <p className="text-lg mb-2">No articles match your search.</p>
                  <button
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedDecade("All");
                    }}
                    className="text-primary hover:underline text-sm"
                  >
                    Clear filters
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Popular Articles ── */}
        {activeTab === "popular" && (
          <div className="space-y-4">
            {popularArticles.map((article, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
              >
                <h3 className="font-bold text-xl text-secondary mb-2">
                  {article.title}
                </h3>
                <p className="text-gray-600">
                  Published in{" "}
                  <span className="font-medium">{article.publication}</span>,{" "}
                  {article.year}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Publications;
